

public class Employee{
	
	private int employeeId;
	private String name;
	private int hours;
	private double rate;
	private static String level;
	
		
	static {
		level = "XYZ";
		System.out.println("In Employee static block: level "+level);
	}
	
	public static String getLevel() {
		System.out.println("In Employee static getLevel: level "+level);
		
		return level;
	}

	public static void setLevel(String level) {
		Employee.level = level;
		System.out.println("In Employee static setLevel: level "+level);
	}
	
	public Employee() {}
	
	public Employee(int employeeId, String name, int hours, double rate){
		  this.employeeId = employeeId;
	      this.name = name;
	      this.hours = hours;
	      this.rate = rate;
	   }

	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public double getRate() {
		System.out.println("In Employee getRate: level "+level);
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public int getEmployeeId() { 
    	System.out.println("in Empoyee, getEmployeeId");
 	   //ClusterObjectManagerEmployee.printTable();

	      return employeeId; 
	}  
    public void setEmployeeId(int employeeId) { 
      this.employeeId = employeeId; 
    } 
    public String getName() { 
      return name; 
    } 
    public void setName(String name) { 
      this.name = name; 
    }
    
    
	
}
